#Write a program to perform outlier analysis using the Z-score method.
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# Load dataset
data = pd.read_csv("data3.csv")

# Z-score calculation
z_scores = (data - data.mean()) / data.std()
outliers = data[(z_scores.abs() > 3).any(axis=1)]

print("Outliers detected using Z-Score method:\n", outliers)

# ---- OPTIONAL PLOT ----
# plt.scatter(data.iloc[:,0], data.iloc[:,1], label="Normal")
# plt.scatter(outliers.iloc[:,0], outliers.iloc[:,1], c="r", label="Outliers")
# plt.title("Z-Score Outlier Detection")
# plt.legend()
# plt.show()
