import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.cluster import DBSCAN

# Load dataset
data = pd.read_csv("data2.csv").values

# DBSCAN Clustering
db = DBSCAN(eps=5, min_samples=2).fit(data)
labels = db.labels_

print("DBSCAN Labels:", labels)

# ---- OPTIONAL PLOT ----
# plt.scatter(data[:,0], data[:,1], c=labels)
# plt.title("DBSCAN Clustering")
# plt.xlabel("X")
# plt.ylabel("Y")
# plt.show()
