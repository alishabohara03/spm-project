import pandas as pd
import numpy as np
from sklearn.cluster import KMeans
import matplotlib.pyplot as plt

# Load dataset
data = pd.read_csv("data.csv").values

# Simple Divisive Clustering: Top-Down using KMeans split
def divisive(X, k=3):
    clusters = [X]  # start with all data in one cluster
    while len(clusters) < k:
        largest = max(clusters, key=len)  # choose largest cluster
        clusters.remove(largest)
        km = KMeans(n_clusters=2, random_state=42).fit(largest)
        labels = km.labels_
        clusters.append(largest[labels == 0])
        clusters.append(largest[labels == 1])
    return clusters

clusters = divisive(data, 3)
print("Divisive clustering produced", len(clusters), "clusters")

# ---- OPTIONAL PLOT ----
# colors = ["r", "g", "b"]
# for i, cluster in enumerate(clusters):
#     plt.scatter(cluster[:, 0], cluster[:, 1], c=colors[i], label=f"Cluster {i+1}")
# plt.title("Divisive Clustering")
# plt.legend()
# plt.show()
