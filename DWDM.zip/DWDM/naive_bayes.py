import pandas as pd
import numpy as np

# -----------------------------
# Load dataset (change CSV file)
# -----------------------------
data = pd.read_csv("data.csv")  # last column is target class
X = data.iloc[:, :-1]  # features
y = data.iloc[:, -1]   # target

# -----------------------------
# Simple Naive Bayes for categorical data
# -----------------------------
classes = y.unique()
feature_probs = {}

for c in classes:
    subset = X[y==c]
    probs = {}
    for col in X.columns:
        probs[col] = subset[col].value_counts(normalize=True).to_dict()
    feature_probs[c] = probs

print("Naive Bayes probabilities (simplified):")
for cls, feats in feature_probs.items():
    print("Class:", cls)
    for feat, prob in feats.items():
        print(" ", feat, "->", prob)
