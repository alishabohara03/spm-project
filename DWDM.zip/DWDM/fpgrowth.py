import pandas as pd
from collections import defaultdict

# -----------------------------
# Load dataset (change CSV file as needed)
# -----------------------------
data = pd.read_csv("data.csv")  # CSV with transactions
transactions = data.values.tolist()

min_support = 2

# -----------------------------
# Simple FP-Growth (Frequent Items Only)
# -----------------------------
def fpgrowth(transactions, min_support):
    # Count frequency
    freq = defaultdict(int)
    for transaction in transactions:
        for item in transaction:
            freq[item] += 1
    # Filter by min_support
    freq = {k:v for k,v in freq.items() if v >= min_support}
    return freq

frequent_items = fpgrowth(transactions, min_support)
print("Frequent Items (FP-Growth simplified):")
for item, support in frequent_items.items():
    print(item, "-> Support:", support)
