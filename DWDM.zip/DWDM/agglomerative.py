import pandas as pd
from scipy.cluster.hierarchy import linkage, dendrogram
import matplotlib.pyplot as plt

# Load dataset
data = pd.read_csv("data.csv").values

# Perform Agglomerative Hierarchical Clustering
Z = linkage(data, method="ward")  # 'ward' minimizes variance

print("Agglomerative linkage matrix:\n", Z)

# ---- OPTIONAL PLOT ----
# dendrogram(Z)
# plt.title("Agglomerative Hierarchical Clustering")
# plt.xlabel("Data Points")
# plt.ylabel("Distance")
# plt.show()
