# --------------------------
# K-Means++ from scratch
# --------------------------

import pandas as pd
import numpy as np
import random
from scipy.spatial.distance import euclidean
import matplotlib.pyplot as plt   # only needed if you want graph

# Step 1: K-Means++ initialization
def kmeans_plus_plus_init(X, k):
    centroids = [random.choice(X)]   # pick first random point
    for _ in range(1, k):
        distances = np.array([min([euclidean(x, c) for c in centroids]) for x in X])
        probs = distances / distances.sum()   # probability proportional to distance
        chosen = X[np.random.choice(len(X), p=probs)]
        centroids.append(chosen)
    return np.array(centroids)

# Step 2: Run K-Means algorithm
def kmeans_pp(X, k, max_iters=100):
    centroids = kmeans_plus_plus_init(X, k)
    for _ in range(max_iters):
        clusters = [[] for _ in range(k)]
        
        # Assign points to nearest centroid
        for point in X:
            distances = [euclidean(point, c) for c in centroids]
            cluster_index = np.argmin(distances)
            clusters[cluster_index].append(point)
        
        # Recalculate centroids
        new_centroids = [np.mean(c, axis=0) if c else centroids[i] for i, c in enumerate(clusters)]
        
        # Stop if centroids don’t move much
        if np.allclose(new_centroids, centroids):
            break
        centroids = new_centroids
    
    return centroids, clusters

# --------------------------
# MAIN PROGRAM
# --------------------------
X = pd.read_csv("xy.csv").values   # load dataset from CSV
centers, clusters = kmeans_pp(X, 3) # k=3 clusters

print("K-Means++ Centers:")
print(np.array(centers))

# --------------------------
# OPTIONAL: Plot graph
# --------------------------
# colors = ["r", "g", "b"]
# for i, cluster in enumerate(clusters):
#     cluster = np.array(cluster)
#     plt.scatter(cluster[:, 0], cluster[:, 1], c=colors[i], label=f"Cluster {i+1}")
# centers = np.array(centers)
# plt.scatter(centers[:, 0], centers[:, 1], c="black", marker="*", s=200, label="Centers")
# plt.title("K-Means++ Clustering")
# plt.legend()
# plt.show()
