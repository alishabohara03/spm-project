import pandas as pd
import numpy as np

# -----------------------------
# Load dataset
# -----------------------------
data = pd.read_csv("xy.csv")  # last column is target
X = data.iloc[:, :-1]
y = data.iloc[:, -1]

# -----------------------------
# Simple ID3 algorithm
# -----------------------------
def entropy(target):
    values = target.value_counts(normalize=True)
    return -sum(values * np.log2(values))

def info_gain(data, feature, target):
    total_entropy = entropy(target)
    values = data[feature].unique()
    weighted_entropy = 0
    for val in values:
        subset = target[data[feature]==val]
        weighted_entropy += len(subset)/len(target) * entropy(subset)
    return total_entropy - weighted_entropy

features = X.columns.tolist()
for feature in features:
    ig = info_gain(X, feature, y)
    print(f"Information Gain for {feature}:", ig)
