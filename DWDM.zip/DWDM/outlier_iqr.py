#Write a program to perform outlier detection using IQR method.
#IQR stands for Interquartile Range.
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# Load dataset
data = pd.read_csv("data3.csv")

# IQR Method
Q1 = data.quantile(0.25)
Q3 = data.quantile(0.75)
IQR = Q3 - Q1
outliers = data[((data < (Q1 - 1.5*IQR)) | (data > (Q3 + 1.5*IQR))).any(axis=1)]

print("Outliers detected using IQR method:\n", outliers)

# ---- OPTIONAL PLOT ----
# plt.scatter(data.iloc[:,0], data.iloc[:,1], label="Normal")
# plt.scatter(outliers.iloc[:,0], outliers.iloc[:,1], c="r", label="Outliers")
# plt.title("IQR Outlier Detection")
# plt.legend()
# plt.show()
