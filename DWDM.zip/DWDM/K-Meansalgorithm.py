# import pandas as pd
# import numpy as np
# import random
# import matplotlib.pyplot as plt

# def euclidean(a, b):
#     return np.sqrt(np.sum((a - b) ** 2))

# def kmeans(X, k, max_iters=100):
#     # Step 1: Randomly select k centroids
#     centroids = X[random.sample(range(len(X)), k)]

#     for _ in range(max_iters):
#         # Step 2: Assign points to nearest centroid
#         clusters = [[] for _ in range(k)]
#         for point in X:
#             distances = [euclidean(point, c) for c in centroids]
#             cluster_idx = np.argmin(distances)
#             clusters[cluster_idx].append(point)

#         # Step 3: Update centroids
#         new_centroids = [np.mean(cluster, axis=0) if cluster else centroids[i]
#                          for i, cluster in enumerate(clusters)]

#         # Convergence check
#         if np.allclose(new_centroids, centroids):
#             break
#         centroids = new_centroids

#     return centroids, clusters

# # Load dataset
# data = pd.read_csv("xy.csv").values
# centers, groups = kmeans(data, k=3)
# print("Cluster Centers:", centers)


# if graph plot asked then 

import pandas as pd
import numpy as np
import random
import matplotlib.pyplot as plt

def euclidean(a, b):
    return np.sqrt(np.sum((a - b) ** 2))

def kmeans(X, k, max_iters=100):
    centroids = X[random.sample(range(len(X)), k)]
    for _ in range(max_iters):
        clusters = [[] for _ in range(k)]
        for point in X:
            distances = [euclidean(point, c) for c in centroids]
            clusters[np.argmin(distances)].append(point)
        new_centroids = [np.mean(cluster, axis=0) if cluster else centroids[i]
                         for i, cluster in enumerate(clusters)]
        if np.allclose(new_centroids, centroids): break
        centroids = new_centroids
    return centroids, clusters

# Load dataset
data = pd.read_csv("xy.csv").values
centers, clusters = kmeans(data, 3)

print("Cluster Centers:", centers)

# ---- PLOT ----
colors = ["r", "g", "b"]
for i, cluster in enumerate(clusters):
    cluster = np.array(cluster)
    plt.scatter(cluster[:, 0], cluster[:, 1], c=colors[i], label=f"Cluster {i+1}")

centers = np.array(centers)
plt.scatter(centers[:, 0], centers[:, 1], c="black", marker="*", s=200, label="Centers")
plt.xlabel("X")
plt.ylabel("Y")
plt.title("K-Means Clustering")
plt.legend()
plt.show()

import pandas as pd
import numpy as np
import random
import matplotlib.pyplot as plt

# Euclidean distance
def euclidean(a, b):
    return np.sqrt(np.sum((a - b) ** 2))

# K-Means++ initialization
def initialize_centroids(X, k):
    centroids = [X[random.randint(0, len(X)-1)]]
    for _ in range(1, k):
        distances = [min([euclidean(x, c) for c in centroids]) for x in X]
        probs = distances / np.sum(distances)
        next_centroid = X[np.random.choice(len(X), p=probs)]
        centroids.append(next_centroid)
    return centroids

def kmeans_pp(X, k, max_iters=100):
    centroids = initialize_centroids(X, k)
    for _ in range(max_iters):
        clusters = [[] for _ in range(k)]
        for point in X:
            distances = [euclidean(point, c) for c in centroids]
            clusters[np.argmin(distances)].append(point)
        new_centroids = [np.mean(cluster, axis=0) if cluster else centroids[i]
                         for i, cluster in enumerate(clusters)]
        if np.allclose(new_centroids, centroids):
            break
        centroids = new_centroids
    return centroids, clusters

# Load dataset
data = pd.read_csv("data.csv").values
centers, clusters = kmeans_pp(data, 3)
print("Cluster Centers:", centers)

# ---- OPTIONAL PLOT ----
# colors = ["r", "g", "b"]
# for i, cluster in enumerate(clusters):
#     cluster = np.array(cluster)
#     plt.scatter(cluster[:, 0], cluster[:, 1], c=colors[i], label=f"Cluster {i+1}")
# centers = np.array(centers)
# plt.scatter(centers[:, 0], centers[:, 1], c="black", marker="*", s=200, label="Centers")
# plt.title("K-Means++ Clustering")
# plt.legend()
# plt.show()
