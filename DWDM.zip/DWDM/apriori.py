import pandas as pd
from itertools import combinations

# -----------------------------
# Load dataset (change CSV file as needed)
# -----------------------------
data = pd.read_csv("data.csv")  # your CSV with transactions
transactions = data.values.tolist()  # list of lists

# Minimum support
min_support = 2

# -----------------------------
# Apriori Function
# -----------------------------
def apriori(transactions, min_support):
    items = set(i for transaction in transactions for i in transaction)
    freq_items = {frozenset([i]): 0 for i in items}

    # Count support for 1-itemsets
    for transaction in transactions:
        for item in freq_items:
            if item.issubset(transaction):
                freq_items[item] += 1
    freq_items = {k: v for k, v in freq_items.items() if v >= min_support}
    all_freq_items = dict(freq_items)

    k = 2
    while freq_items:
        candidate_items = set([i.union(j) for i in freq_items for j in freq_items if len(i.union(j))==k])
        freq_items = {item: 0 for item in candidate_items}
        for transaction in transactions:
            for item in freq_items:
                if item.issubset(transaction):
                    freq_items[item] += 1
        freq_items = {k: v for k, v in freq_items.items() if v >= min_support}
        all_freq_items.update(freq_items)
        k += 1
    return all_freq_items

# -----------------------------
# Run Apriori
# -----------------------------
frequent_items = apriori(transactions, min_support)
print("Frequent Itemsets:")
for item, support in frequent_items.items():
    print(set(item), "-> Support:", support)
