import pandas as pd
import numpy as np
import random
import matplotlib.pyplot as plt

def euclidean(a, b):
    return np.sqrt(np.sum((a - b) ** 2))

def kmedoids(X, k, max_iters=100):
    medoids = X[random.sample(range(len(X)), k)]
    for _ in range(max_iters):
        clusters = [[] for _ in range(k)]
        for point in X:
            distances = [euclidean(point, m) for m in medoids]
            clusters[np.argmin(distances)].append(point)
        new_medoids = []
        for cluster in clusters:
            if cluster:
                cluster = np.array(cluster)
                distances = [[euclidean(p, q) for q in cluster] for p in cluster]
                medoid = cluster[np.argmin(np.sum(distances, axis=1))]
                new_medoids.append(medoid)
        if np.allclose(new_medoids, medoids):
            break
        medoids = new_medoids
    return medoids, clusters

data = pd.read_csv("data.csv").values
medoids, clusters = kmedoids(data, 3)
print("Medoids:", medoids)

# ---- OPTIONAL PLOT ----
# colors = ["r", "g", "b"]
# for i, cluster in enumerate(clusters):
#     cluster = np.array(cluster)
#     plt.scatter(cluster[:, 0], cluster[:, 1], c=colors[i], label=f"Cluster {i+1}")
# medoids = np.array(medoids)
# plt.scatter(medoids[:, 0], medoids[:, 1], c="black", marker="D", s=200, label="Medoids")
# plt.title("K-Medoids Clustering")
# plt.legend()
# plt.show()
