import pandas as pd
import numpy as np
import random
import matplotlib.pyplot as plt

# Euclidean distance
def euclidean(a, b):
    return np.sqrt(np.sum((a - b) ** 2))

# Mini-Batch KMeans
def minibatch_kmeans(X, k=3, batch_size=10, max_iters=100):
    centroids = X[random.sample(range(len(X)), k)]
    for _ in range(max_iters):
        batch = X[np.random.choice(len(X), batch_size)]
        clusters = [[] for _ in range(k)]
        for point in batch:
            distances = [euclidean(point, c) for c in centroids]
            clusters[np.argmin(distances)].append(point)
        for i, cluster in enumerate(clusters):
            if cluster:
                centroids[i] = np.mean(cluster, axis=0)
    return centroids

# Load dataset
data = pd.read_csv("data4.csv").values
centers = minibatch_kmeans(data, 3)
print("Mini-Batch KMeans Cluster Centers:\n", centers)

# ---- OPTIONAL PLOT ----
# plt.scatter(data[:,0], data[:,1], c="blue", label="Points")
# plt.scatter(centers[:,0], centers[:,1], c="red", marker="*", s=200, label="Centers")
# plt.title("Mini-Batch KMeans")
# plt.legend()
# plt.show()
